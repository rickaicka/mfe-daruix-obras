import { DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable, finalize } from 'rxjs';
import type { TenderBid, TenderDetail, TenderRow } from '../../models/leilao-reverso.model';
import { CotacoesService } from '../../services/cotacoes.service';

@Component({
  standalone: true,
  imports: [DatePipe, FormsModule],
  styleUrl: './leilao-reverso.scss',
  templateUrl: './leilao-reverso.html',
})
export class LeilaoReverso {
  private readonly cotacoes = inject(CotacoesService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly route = inject(ActivatedRoute);
  readonly rows = signal<TenderRow[]>([]);
  readonly page = signal(1);
  readonly total = signal(0);
  readonly detail = signal<TenderDetail | null>(null);
  readonly draft = signal<TenderBid | null>(null);
  readonly busy = signal(false);
  readonly error = signal('');

  constructor() {
    this.route.queryParamMap.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(params => {
      const id = params.get('mapa');
      if (id && /^\d+$/.test(id)) this.open(Number(id));
      else this.load(1);
    });
  }

  load(page: number): void {
    this.run(this.cotacoes.listTenders(page), result => {
      this.rows.set(result.results);
      this.total.set(result.count);
      this.page.set(page);
    });
  }

  back(): void {
    this.detail.set(null);
    this.draft.set(null);
    this.load(this.page());
  }

  open(id: number): void {
    this.run(this.cotacoes.getTender(id), result => this.show(result));
  }

  // Convite já cria a participação; endpoint mantido para compatibilidade.
  participate(id: number): void {
    this.run(this.cotacoes.participate(id), result => this.show(result));
  }

  send(id: number, draft: TenderBid): void {
    const decimal = (value: string | null) => value?.trim().replace(',', '.') || null;
    const body = {
      ...draft, quoted_on: draft.quoted_on || null,
      freight: decimal(draft.freight) ?? '0', discount: decimal(draft.discount) ?? '0',
      offers: draft.offers.filter(offer => decimal(offer.unit_price) !== null).map(offer => ({
        item_id: offer.item_id, unit_price: decimal(offer.unit_price),
        available_quantity: null, brand: '', notes: offer.notes,
      })),
    };
    if (!body.offers.length) {
      this.error.set('Informe um preço para pelo menos um item.');
      return;
    }
    this.run(this.cotacoes.sendBid(id, body), result => this.show(result));
  }

  private show(result: TenderDetail): void {
    const own = result.own_offer;
    const offers = new Map(own?.offers.map(offer => [offer.item_id, offer]));
    this.detail.set(result);
    this.draft.set({
      payment: '', delivery: '', validity: '', quoted_on: null, freight: '0', discount: '0', notes: '',
      ...own,
      offers: result.items.map(item => offers.get(item.id) ?? {
        item_id: item.id, unit_price: null, available_quantity: null, brand: '', notes: '',
      }),
    });
  }

  private run<T>(request: Observable<T>, success: (result: T) => void): void {
    if (this.busy()) return;
    this.error.set('');
    this.busy.set(true);
    request.pipe(finalize(() => this.busy.set(false)), takeUntilDestroyed(this.destroyRef)).subscribe({
      next: success,
      error: (response: HttpErrorResponse) => this.error.set(response.error?.detail ?? 'Confira os campos e tente novamente.'),
    });
  }
}
