import { Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  ButtonComponent, CardSquareComponent, DrxDataTableComponent, DrxSelectComponent,
  InputComponent, type DrxTableAction, type DrxTableColumn, type DrxTableQuery,
  type DrxTableRowAction,
} from '@daruix/hub-ui';
import { finalize } from 'rxjs';
import type { SupplierPortalProfile, SupplierRegistryEntry } from '../../models/fornecedor-cotacao.model';
import { CotacoesService } from '../../services/cotacoes.service';

@Component({
  standalone: true,
  imports: [ButtonComponent, CardSquareComponent, DrxDataTableComponent, DrxSelectComponent, InputComponent],
  styleUrl: './fornecedores-cotacao.scss',
  templateUrl: './fornecedores-cotacao.html',
})
export class FornecedoresCotacao {
  private readonly cotacoes = inject(CotacoesService);
  private readonly destroyRef = inject(DestroyRef);
  readonly rows = signal<SupplierRegistryEntry[]>([]);
  readonly profiles = signal<SupplierPortalProfile[]>([]);
  readonly draft = signal<SupplierRegistryEntry | null>(null);
  readonly error = signal('');
  readonly busy = signal(false);
  readonly page = signal(1);
  readonly total = signal(0);
  readonly search = signal('');
  readonly profileOptions = computed(() => {
    const supplier = this.draft();
    const options = [{ value: 'none', label: 'Sem conta vinculada', disabled: false }];
    for (const profile of this.profiles()) {
      options.push({
        value: String(profile.id),
        label: [profile.name, profile.document].filter(Boolean).join(' · '),
        disabled: profile.linked_supplier !== null && profile.linked_supplier !== supplier?.id,
      });
    }
    const current = supplier?.portal_profile;
    if (current && !options.some(option => option.value === String(current))) {
      options.push({ value: String(current), label: `Perfil atual #${current}`, disabled: false });
    }
    return options;
  });
  readonly columns: readonly DrxTableColumn<SupplierRegistryEntry>[] = [
    { key: 'name', label: 'Fornecedor', value: row => row.name },
    { key: 'document', label: 'Documento', value: row => row.document },
    { key: 'contact', label: 'Contato', value: row => row.contact },
    {
      key: 'active', label: 'Status', value: row => row.active ? 'Ativo' : 'Inativo',
      badge: row => ({ label: row.active ? 'Ativo' : 'Inativo', tone: row.active ? 'success' : 'neutral' }),
    },
  ];
  readonly actions: readonly DrxTableAction<SupplierRegistryEntry>[] = [
    { id: 'edit', label: 'Editar', icon: 'pencil', disabled: () => this.busy() },
  ];
  profileSearch = '';
  readonly fields = [
    { key: 'name', label: 'Razão social / nome' }, { key: 'trade_name', label: 'Nome fantasia' }, { key: 'document', label: 'CNPJ / CPF' },
    { key: 'contact', label: 'Contato' }, { key: 'phone', label: 'Telefone' },
    { key: 'email', label: 'E-mail' }, { key: 'fax', label: 'Fax' },
    { key: 'business_segment', label: 'Ramo empresarial' }, { key: 'website', label: 'Site' },
    { key: 'payment_terms', label: 'Condições de pagamento' }, { key: 'delivery_terms', label: 'Prazo de entrega' },
    { key: 'address', label: 'Endereço' }, { key: 'notes', label: 'Observações' },
  ] as const;

  constructor() { this.load(1); }

  load(page: number): void {
    this.busy.set(true);
    this.error.set('');
    this.cotacoes.listSupplierRegistry(this.search(), page).pipe(
      finalize(() => this.busy.set(false)), takeUntilDestroyed(this.destroyRef),
    ).subscribe({
      next: result => { this.rows.set(result.results); this.total.set(result.count); this.page.set(page); },
      error: () => this.error.set('Não foi possível carregar os fornecedores.'),
    });
  }

  edit(supplier?: SupplierRegistryEntry): void {
    this.profiles.set([]);
    this.profileSearch = '';
    this.draft.set(supplier ? { ...supplier } : {
      name: '', document: '', trade_name: '', business_segment: '', website: '', payment_terms: '', delivery_terms: '', contact: '', phone: '', email: '', fax: '', address: '', notes: '',
      active: true, portal_profile: null,
    });
  }

  findProfiles(): void {
    this.cotacoes.searchPortalProfiles(this.profileSearch).pipe(
      takeUntilDestroyed(this.destroyRef),
    ).subscribe({
      next: result => this.profiles.set(result.results),
      error: () => this.error.set('Não foi possível buscar contas de fornecedores.'),
    });
  }

  updateQuery(query: DrxTableQuery): void {
    this.search.set(query.search);
    this.load(query.page);
  }

  rowAction(event: DrxTableRowAction<SupplierRegistryEntry>): void {
    this.edit(event.row);
  }

  changeProfile(supplier: SupplierRegistryEntry, value: string): void {
    supplier.portal_profile = value === 'none' || !value ? null : Number(value);
    this.draft.set({ ...supplier });
  }

  save(supplier: SupplierRegistryEntry): void {
    if (this.busy() || !supplier.name.trim()) return;
    this.busy.set(true);
    this.error.set('');
    this.cotacoes.saveSupplier(supplier).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => { this.draft.set(null); this.load(this.page()); },
      error: response => {
        this.busy.set(false);
        this.error.set(response.error?.portal_profile?.[0] ?? 'Não foi possível salvar o fornecedor.');
      },
    });
  }
}
