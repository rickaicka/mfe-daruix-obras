import { HttpErrorResponse } from '@angular/common/http';
import { Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import {
  ButtonComponent,
  CardSquareComponent,
  DrxBadgeComponent,
  DrxCalendarComponent,
  DrxDataTableComponent,
  InputComponent,
  TextareaComponent,
  type DrxBadgeTone,
  type DrxTableAction,
  type DrxTableColumn,
  type DrxTableQuery,
  type DrxTableRowAction,
  HubIconComponent,
} from '@daruix/hub-ui';
import { Subject, catchError, finalize, of, startWith, switchMap } from 'rxjs';

import {
  QUOTATION_STATUS,
  type QuotationItem,
  type QuotationMap,
  type QuotationMapAction,
  type QuotationMapRow,
  type QuotationOffer,
  type QuotationSupplier,
} from '../../models/mapa-cotacao.model';
import { CotacoesService } from '../../services/cotacoes.service';
import { buildComparisonTree, visibleComparisonRows } from './mapa-composicoes';

const quantityFormatter = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 6 });
const brlFormatter = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

@Component({
  selector: 'app-mapas-cotacao',
  standalone: true,
  imports: [
    DatePipe,
    FormsModule,
    ButtonComponent,
    CardSquareComponent,
    DrxBadgeComponent,
    DrxCalendarComponent,
    DrxDataTableComponent,
    InputComponent,
    TextareaComponent,
    HubIconComponent,
  ],
  templateUrl: './mapas-cotacao.html',
  styleUrl: './mapas-cotacao.scss',
})
export class MapasCotacao {
  private readonly cotacoes = inject(CotacoesService);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);
  private readonly refresh = new Subject<void>();
  private readonly openMap = new Subject<number | null>();
  private readonly supplierSearch = new Subject<string>();

  readonly expandedCompositions = signal<ReadonlySet<string>>(new Set());
  private readonly comparisonTree = computed(() => buildComparisonTree(this.map()?.items ?? []));
  readonly comparisonRows = computed(() =>
    visibleComparisonRows(this.comparisonTree(), this.expandedCompositions()),
  );

  readonly rows = signal<QuotationMapRow[]>([]);
  readonly total = signal(0);
  readonly query = signal<DrxTableQuery | null>(null);
  readonly loading = signal(false);
  readonly busy = signal(false);
  readonly dirty = signal(false);
  readonly error = signal('');
  readonly map = signal<QuotationMap | null>(null);
  readonly matches = signal<QuotationSupplier[]>([]);
  readonly supplierTerm = signal('');
  readonly supplierCount = signal(0);
  readonly tenderPending = computed(
    () => !!this.map()?.tender_opened_at && !this.map()?.tender_closed_at,
  );
  readonly tenderDate = signal('');
  readonly tenderTime = signal('');
  readonly tenderDeadline = computed(() => {
    const date = this.tenderDate();
    const time = this.tenderTime().trim();
    return date && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time) ? `${date}T${time}` : '';
  });
  readonly writable = computed(
    () =>
      !this.tenderPending() && (this.map()?.status === 'READY' || this.map()?.status === 'DRAFT'),
  );
  readonly status = QUOTATION_STATUS;
  readonly statusTones: Record<QuotationMapRow['status'], DrxBadgeTone> = {
    READY: 'info',
    DRAFT: 'warning',
    FINAL: 'success',
    ORDERED: 'success',
    CANCELLED: 'neutral',
  };

  readonly columns: readonly DrxTableColumn<QuotationMapRow>[] = [
    {
      key: 'code',
      label: 'Mapa',
      value: (row) => row.code,
      filterable: true,
      filter: { type: 'text' },
    },
    { key: 'pc', label: 'PC', value: (row) => row.pc, filterable: true, filter: { type: 'text' } },
    { key: 'rm', label: 'RM', value: (row) => row.rm, filterable: true, filter: { type: 'text' } },
    {
      key: 'work',
      label: 'Obra',
      value: (row) => row.work,
      filterable: true,
      filter: { type: 'text' },
    },
    {
      key: 'status',
      label: 'Status',
      value: (row) => row.status,
      display: (row) => QUOTATION_STATUS[row.status],
      badge: (row) => ({ label: QUOTATION_STATUS[row.status], tone: this.statusTones[row.status] }),
      filterable: true,
      filter: {
        type: 'select',
        options: Object.entries(QUOTATION_STATUS).map(([value, label]) => ({ value, label })),
      },
    },
  ];

  readonly actions: readonly DrxTableAction<QuotationMapRow>[] = [
    {
      id: 'quote',
      label: 'Montar cotação',
      icon: 'pencil',
      hidden: (row) => row.status !== 'READY',
    },
    { id: 'open', label: 'Abrir mapa', icon: 'eye', hidden: (row) => row.status === 'READY' },
  ];

  constructor() {
    this.refresh
      .pipe(
        startWith(undefined),
        switchMap(() => {
          this.loading.set(true);
          const query = this.query();
          return this.cotacoes
            .listMaps({
              page: query?.page ?? 1,
              pageSize: query?.pageSize ?? 20,
              search: query?.search ?? '',
              filters: query?.filters ?? {},
            })
            .pipe(
              catchError((error) => {
                this.report(error);
                return of(null);
              }),
              finalize(() => this.loading.set(false)),
            );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((page) => {
        if (!page) return;
        this.rows.set(page.results);
        this.total.set(page.count);
      });

    this.openMap
      .pipe(
        switchMap((id) => {
          this.map.set(null);
          if (id === null) return of(null);
          return this.cotacoes.getMap(id).pipe(
            catchError((error) => {
              this.report(error);
              return of(null);
            }),
          );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((map) => this.map.set(map ? this.fillOffers(map) : null));

    this.supplierSearch
      .pipe(
        switchMap((search) =>
          this.cotacoes.searchSuppliers(search).pipe(
            catchError((error) => {
              this.report(error);
              return of(null);
            }),
          ),
        ),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((page) => {
        this.matches.set(page?.results ?? []);
        this.supplierCount.set(page?.count ?? 0);
      });

    this.route.queryParamMap.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((params) => {
      const id = params.get('mapa');
      this.open(id && /^\d+$/.test(id) ? Number(id) : null);
    });
  }

  updateQuery(query: DrxTableQuery): void {
    this.query.set(query);
    this.refresh.next();
  }

  rowAction(event: DrxTableRowAction<QuotationMapRow>): void {
    this.navigate(event.row.id);
  }

  navigate(id: number | null): void {
    if (this.busy()) return;
    void this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { mapa: id },
      queryParamsHandling: 'merge',
    });
  }

  toggleComposition(key: string): void {
    this.expandedCompositions.update((current) => {
      const next = new Set(current);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  private open(id: number | null): void {
    if (this.busy()) return;
    this.error.set('');
    this.matches.set([]);
    this.supplierCount.set(0);
    this.supplierTerm.set('');
    this.dirty.set(false);
    this.tenderDate.set('');
    this.tenderTime.set('');
    this.expandedCompositions.set(new Set());
    this.openMap.next(id);
  }

  searchSuppliers(): void {
    this.supplierSearch.next(this.supplierTerm().trim());
  }

  addSupplier(supplier: QuotationSupplier): void {
    const map = this.map();
    if (
      !map ||
      map.quotes.length >= 6 ||
      map.quotes.some((quote) => quote.supplier.id === supplier.id)
    )
      return;
    this.dirty.set(true);
    map.quotes.push({
      supplier: { ...supplier },
      offers: map.items.map((item) => this.emptyOffer(item.id)),
      payment: '',
      delivery: '',
      validity: '',
      quoted_on: null,
      freight: '0',
      discount: '0',
      notes: '',
    });
  }

  choose(offer: QuotationOffer): void {
    this.dirty.set(true);
    for (const quote of this.map()?.quotes ?? []) {
      for (const candidate of quote.offers) {
        if (candidate.item_id === offer.item_id) candidate.selected = candidate === offer;
      }
    }
  }

  lowest(itemIndex: number): number | null {
    const prices = (this.map()?.quotes ?? [])
      .map((quote) => quote.offers[itemIndex]?.unit_price)
      .filter((price) => price != null && price !== '')
      .map((price) => Number(price?.replace(',', '.')))
      .filter(Number.isFinite);
    return prices.length ? Math.min(...prices) : null;
  }

  mutate(action: 'save' | QuotationMapAction): void {
    const map = this.map();
    if (!map || this.busy() || (action === 'finalize' && this.dirty())) return;
    const deadline = new Date(this.tenderDeadline());
    if (
      action === 'publish-tender' &&
      (this.dirty() || !Number.isFinite(deadline.getTime()) || deadline <= new Date())
    ) {
      this.error.set('Salve as alterações e informe um prazo futuro para publicar.');
      return;
    }
    this.error.set('');
    this.busy.set(true);
    const response =
      action === 'save'
        ? this.cotacoes.saveMap(map.id, {
            version: map.version,
            notes: map.notes,
            quotes: map.quotes.map(({ supplier, ...quote }) => ({
              ...quote,
              supplier_id: supplier.id,
              contact: supplier.contact,
              phone: supplier.phone,
              email: supplier.email,
              quoted_on: quote.quoted_on || null,
              freight: this.decimal(quote.freight) ?? '0',
              discount: this.decimal(quote.discount) ?? '0',
              offers: quote.offers.map((offer) => ({
                ...offer,
                unit_price: this.decimal(offer.unit_price),
                available_quantity: this.decimal(offer.available_quantity),
              })),
            })),
          })
        : this.cotacoes.changeMapState(
            map.id,
            action,
            map.version,
            action === 'publish-tender' ? deadline.toISOString() : undefined,
          );
    response
      .pipe(
        finalize(() => this.busy.set(false)),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: (updated) => {
          this.dirty.set(false);
          this.map.set(this.fillOffers(updated));
          this.refresh.next();
        },
        error: (error) => this.report(error),
      });
  }

  formatQuantity(value: string): string {
    const amount = Number(value);
    return Number.isFinite(amount) ? quantityFormatter.format(amount) : value;
  }

  formatBrl(value: number | string | null): string {
    if (value === null || value === '') return '—';
    const amount = Number(value);
    return Number.isFinite(amount) ? brlFormatter.format(amount) : '—';
  }

  lineTotal(item: QuotationItem, offer: QuotationOffer): number | null {
    const price = this.decimal(offer.unit_price);
    return price === null ? null : Number(price) * Number(item.quantity) * (item.period ?? 1);
  }

  private decimal(value: string | null): string | null {
    return value?.trim().replace(',', '.') || null;
  }

  private fillOffers(map: QuotationMap): QuotationMap {
    for (const quote of map.quotes) {
      const existing = new Map(quote.offers.map((offer) => [offer.item_id, offer]));
      quote.offers = map.items.map((item) => existing.get(item.id) ?? this.emptyOffer(item.id));
    }
    return map;
  }

  private emptyOffer(item_id: number): QuotationOffer {
    return {
      item_id,
      unit_price: null,
      available_quantity: null,
      brand: '',
      notes: '',
      selected: false,
    };
  }

  private report(error: HttpErrorResponse): void {
    const response: unknown = error.error;
    const rawText =
      typeof response === 'string'
        ? response
        : response && typeof response === 'object' && 'text' in response
          ? response.text
          : null;
    if (
      error.headers?.get('content-type')?.includes('text/html') ||
      (typeof rawText === 'string' && /^\s*<(?:!doctype\s+html|html[\s>])/i.test(rawText))
    ) {
      this.error.set(
        'A API de cotações retornou uma página HTML. Confira o endereço do BFF ou o proxy do Shell.',
      );
      return;
    }

    const flatten = (value: unknown): string[] => {
      if (typeof value === 'string') return [value];
      if (value && typeof value === 'object') return Object.values(value).flatMap(flatten);
      return [];
    };
    this.error.set(
      (typeof error.error === 'object' && flatten(error.error).join(' ')) ||
        'Não foi possível concluir a operação.',
    );
  }
}
